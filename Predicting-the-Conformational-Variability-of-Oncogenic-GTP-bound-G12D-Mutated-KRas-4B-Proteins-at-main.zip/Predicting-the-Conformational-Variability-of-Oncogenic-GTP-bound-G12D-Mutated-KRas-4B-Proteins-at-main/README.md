command line: gmx mdrun -deffnm 1500ns-metadynamics -v -plumed plumed.dat
